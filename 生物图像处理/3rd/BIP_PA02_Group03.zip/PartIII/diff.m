A = importdata('diff.mat')
